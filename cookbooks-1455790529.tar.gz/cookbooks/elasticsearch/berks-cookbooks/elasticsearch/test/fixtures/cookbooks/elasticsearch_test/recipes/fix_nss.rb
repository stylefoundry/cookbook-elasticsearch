# workaround for http://blog.backslasher.net/java-ssl-crash.html

package 'nss' do
  action :upgrade
end
